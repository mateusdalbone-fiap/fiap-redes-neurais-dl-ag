# Stanford Cars - NO_DAMAGE

Subconjunto de 100 imagens do Stanford Cars Dataset.

As imagens foram selecionadas aleatoriamente
com seed = 42.

Uso no projeto:
- Classe: NO_DAMAGE
- has_damage = 0

Fonte:
https://huggingface.co/datasets/tanganke/stanford_cars

Este subconjunto foi criado exclusivamente
para utilização na aula prática.
